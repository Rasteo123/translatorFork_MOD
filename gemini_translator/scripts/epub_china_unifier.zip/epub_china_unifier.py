import os
import sys
import zipfile
import tkinter as tk
from tkinter import filedialog, messagebox

try:
    from opencc import OpenCC
except ImportError:
    print("❌ Ошибка: Не установлена библиотека OpenCC.")
    print("Установите: pip install opencc-python-reimplemented")
    input("Нажмите Enter для выхода...")
    sys.exit(1)

class EpubUnifier:
    def __init__(self):
        # 't2s' = Traditional Chinese to Simplified Chinese
        # Это самый надежный режим для унификации.
        self.converter = OpenCC('t2s')
        
    def process_file(self, input_path):
        folder = os.path.dirname(input_path)
        filename = os.path.basename(input_path)
        name, ext = os.path.splitext(filename)
        output_path = os.path.join(folder, f"{name}_unified{ext}")

        print(f"📖 Чтение: {filename}")
        print(f"⚙️ Режим: Унификация (Традиционный -> Упрощенный)")

        files_processed = 0
        files_total = 0

        try:
            with zipfile.ZipFile(input_path, 'r') as zin:
                with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zout:
                    file_list = zin.infolist()
                    files_total = len(file_list)

                    for item in file_list:
                        # Читаем сырые байты
                        content_bytes = zin.read(item.filename)
                        
                        # Проверяем, является ли файл текстовым (HTML, NCX, OPF)
                        # Мы конвертируем всё, где может быть текст новеллы или оглавление.
                        if item.filename.lower().endswith(('.html', '.xhtml', '.htm', '.xml', '.opf', '.ncx', '.txt')):
                            try:
                                # Декодируем
                                content_str = content_bytes.decode('utf-8')
                                
                                # --- КОНВЕРТАЦИЯ ---
                                # OpenCC очень умен, он не ломает HTML-теги, 
                                # так как они состоят из латиницы. Он трогает только CJK.
                                new_content_str = self.converter.convert(content_str)
                                
                                if new_content_str != content_str:
                                    content_bytes = new_content_str.encode('utf-8')
                                    files_processed += 1
                                    
                            except UnicodeDecodeError:
                                # Если файл не UTF-8, лучше его не трогать
                                pass
                        
                        # Записываем (измененный или нет) файл в новый архив
                        zout.writestr(item, content_bytes)

            return True, output_path, files_processed
            
        except Exception as e:
            return False, str(e), 0

def main():
    # Скрываем главное окно tkinter
    root = tk.Tk()
    root.withdraw()

    print("📂 Выберите EPUB файл для унификации...")
    file_path = filedialog.askopenfilename(
        title="Выберите EPUB для унификации (Trad -> Simp)",
        filetypes=[("EPUB books", "*.epub")]
    )

    if not file_path:
        print("Отмена.")
        return

    unifier = EpubUnifier()
    
    print("🚀 Начало обработки...")
    success, result, count = unifier.process_file(file_path)

    if success:
        print("\n" + "="*40)
        print(f"✅ ГОТОВО!")
        print(f"Обработано файлов внутри архива: {count}")
        print(f"Сохранено как: {os.path.basename(result)}")
        print("="*40)
        messagebox.showinfo("Успех", f"Файл успешно унифицирован!\n\nИзменено файлов внутри: {count}\nСохранено: {os.path.basename(result)}")
    else:
        print(f"\n❌ ОШИБКА: {result}")
        messagebox.showerror("Ошибка", f"Не удалось обработать файл:\n{result}")

if __name__ == "__main__":
    main()