# -*- coding: utf-8 -*-
# epub_markdown_fixer.py

import sys
import os
import zipfile
import re
import html

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel, 
    QPushButton, QFileDialog, QProgressBar, QTextEdit, QMessageBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal

# ============================================================================
#  ЛОГИКА ОЧИСТКИ (ТОЧНАЯ КОПИЯ УТВЕРЖДЕННОЙ)
# ============================================================================

# 1. Проверка на сепаратор: строка состоит ТОЛЬКО из звезд, пробелов и тире
IS_SEPARATOR_PATTERN = re.compile(r'^[\s*—–−-]+$')

# 2. Поиск текстового контента между тегами: (>)(контент)(<)
# Используем DOTALL, чтобы захватывать переносы строк внутри тега, если они есть
TEXT_NODE_PATTERN = re.compile(r'(>)([^<]+)(<)', re.DOTALL)

# 3. Валидные Markdown пары
MD_BOLD_ITALIC_PATTERN = re.compile(r'(?<!\*)\*\*\*([^\*\n]+?)\*\*\*(?!\*)')
MD_BOLD_PATTERN = re.compile(r'(?<!\*)\*\*([^\*\n]+?)\*\*(?!\*)')
MD_ITALIC_PATTERN = re.compile(r'(?<!\*)\*([^\*\n]+?)\*(?!\*)')

# 4. Мусорные звезды (одиночки на границах слов)
# (?<!\S) - слева пустота или пробел
# (?!\S)  - справа пустота или пробел
MD_GARBAGE_STARS_PATTERN = re.compile(r'(?<!\S)\*+|\*+(?!\S)')

def convert_markdown_to_html(html_text: str) -> str:
    """
    Преобразует Markdown (*, **, ***) в HTML внутри текстовых узлов.
    """
    def process_node(match):
        prefix = match.group(1)  # >
        content = match.group(2) # Текст внутри
        suffix = match.group(3)  # <

        # 1. ПРОВЕРКА НА СЕПАРАТОР
        # Если внутри только звезды, пробелы и тире — это разделитель. Не трогаем.
        if IS_SEPARATOR_PATTERN.fullmatch(content.strip()):
            return match.group(0)

        # 2. КОНВЕРТАЦИЯ ВАЛИДНЫХ ПАР
        content = MD_BOLD_ITALIC_PATTERN.sub(r'<strong><em>\1</em></strong>', content)
        content = MD_BOLD_PATTERN.sub(r'<strong>\1</strong>', content)
        content = MD_ITALIC_PATTERN.sub(r'<em>\1</em>', content)

        # 3. ЗАЧИСТКА МУСОРА (Умная)
        # Удаляем звезды только на границах, сохраняя цензуру (П**ду).
        content = MD_GARBAGE_STARS_PATTERN.sub('', content)

        return f"{prefix}{content}{suffix}"

    # Применяем ко всем текстовым узлам
    return TEXT_NODE_PATTERN.sub(process_node, html_text)

# ============================================================================
#  РАБОЧИЙ ПОТОК
# ============================================================================

class WorkerThread(QThread):
    progress = pyqtSignal(int, int) # current, total
    log = pyqtSignal(str)
    finished = pyqtSignal(str)      # output_path
    error = pyqtSignal(str)

    def __init__(self, input_path):
        super().__init__()
        self.input_path = input_path

    def run(self):
        try:
            directory = os.path.dirname(self.input_path)
            filename = os.path.basename(self.input_path)
            name, ext = os.path.splitext(filename)
            output_path = os.path.join(directory, f"{name}_cleaned{ext}")

            self.log.emit(f"Анализ файла: {filename}...")
            
            with zipfile.ZipFile(self.input_path, 'r') as zin:
                total_files = len(zin.infolist())
                
                with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zout:
                    for i, item in enumerate(zin.infolist()):
                        content = zin.read(item.filename)
                        
                        # Обрабатываем только HTML/XHTML
                        if item.filename.lower().endswith(('.html', '.xhtml', '.htm')):
                            try:
                                text_content = content.decode('utf-8')
                                original_len = len(text_content)
                                
                                # === ПРИМЕНЕНИЕ ЛОГИКИ ===
                                clean_content = convert_markdown_to_html(text_content)
                                # =========================
                                
                                if len(clean_content) != original_len:
                                    self.log.emit(f"  [FIX] Обработан: {item.filename}")
                                
                                zout.writestr(item.filename, clean_content.encode('utf-8'))
                            except Exception as e:
                                self.log.emit(f"  [ERR] Ошибка в файле {item.filename}: {e}")
                                zout.writestr(item, content) # Пишем как было
                        else:
                            # Копируем остальные файлы (картинки, стили, ncx) без изменений
                            zout.writestr(item, content)
                        
                        self.progress.emit(i + 1, total_files)

            self.finished.emit(output_path)

        except Exception as e:
            self.error.emit(str(e))

# ============================================================================
#  ИНТЕРФЕЙС
# ============================================================================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("EPUB Markdown Cleaner")
        self.setGeometry(300, 300, 600, 400)
        self.setAcceptDrops(True)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # Инфо
        self.label = QLabel("<h2>Лечение Markdown в EPUB</h2><p>Перетащите файл сюда или нажмите кнопку.</p>")
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("border: 2px dashed #aaa; padding: 20px; color: #555;")
        layout.addWidget(self.label)

        # Кнопка
        self.btn_select = QPushButton("Выбрать EPUB файл")
        self.btn_select.setMinimumHeight(40)
        self.btn_select.clicked.connect(self.select_file)
        layout.addWidget(self.btn_select)

        # Прогресс
        self.progress_bar = QProgressBar()
        layout.addWidget(self.progress_bar)

        # Лог
        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        layout.addWidget(self.log_view)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        files = [u.toLocalFile() for u in event.mimeData().urls()]
        for f in files:
            if f.lower().endswith('.epub'):
                self.start_processing(f)
                return

    def select_file(self):
        fname, _ = QFileDialog.getOpenFileName(self, 'Выбрать EPUB', '', 'EPUB Files (*.epub)')
        if fname:
            self.start_processing(fname)

    def start_processing(self, path):
        self.btn_select.setEnabled(False)
        self.log_view.clear()
        self.log_view.append(f"<b>Запуск обработки:</b> {path}")
        
        self.worker = WorkerThread(path)
        self.worker.progress.connect(self.update_progress)
        self.worker.log.connect(self.append_log)
        self.worker.finished.connect(self.processing_finished)
        self.worker.error.connect(self.processing_error)
        self.worker.start()

    def update_progress(self, current, total):
        self.progress_bar.setMaximum(total)
        self.progress_bar.setValue(current)

    def append_log(self, text):
        self.log_view.append(text)

    def processing_finished(self, output_path):
        self.btn_select.setEnabled(True)
        self.progress_bar.setValue(self.progress_bar.maximum())
        self.log_view.append(f"<br><b style='color:green'>ГОТОВО!</b> Файл сохранен: {output_path}")
        QMessageBox.information(self, "Успех", f"Обработка завершена!\nФайл: {os.path.basename(output_path)}")

    def processing_error(self, err_msg):
        self.btn_select.setEnabled(True)
        self.log_view.append(f"<br><b style='color:red'>ОШИБКА:</b> {err_msg}")
        QMessageBox.critical(self, "Ошибка", err_msg)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    # Простая темная тема
    app.setStyleSheet("""
        QWidget { background-color: #2c313c; color: #f0f0f0; font-size: 14px; }
        QTextEdit { background-color: #1e222a; border: 1px solid #4d5666; font-family: Consolas; }
        QPushButton { background-color: #4d5666; border-radius: 4px; padding: 5px; }
        QPushButton:hover { background-color: #5a6475; }
        QProgressBar { border: 1px solid #4d5666; text-align: center; }
        QProgressBar::chunk { background-color: #3daee9; }
    """)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())